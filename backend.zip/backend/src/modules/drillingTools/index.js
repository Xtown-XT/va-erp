import drillingToolsRoutes from "./drillingTools.routes.js";

export { drillingToolsRoutes };
