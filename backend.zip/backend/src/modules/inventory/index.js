import inventoryRoutes from "./inventory.routes.js";
import purchaseOrderRoutes from "./purchaseOrder.routes.js";

export { inventoryRoutes, purchaseOrderRoutes };
