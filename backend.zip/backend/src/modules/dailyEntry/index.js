export { default as DailyEntry } from "./dailyEntry.model.js";
export { default as DailyEntryEmployee } from "./dailyEntryEmployee.model.js";
import dailyEntryRoutes from "./dailyEntry.routes.js";

export { dailyEntryRoutes };
