import machineRoutes from "./vehicle.routes.js";

export { machineRoutes };
