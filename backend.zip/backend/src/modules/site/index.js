import siteRoutes from "./site.routes.js";

export { siteRoutes };
