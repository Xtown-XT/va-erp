import supplierRoutes from "./supplier.routes.js";

export { supplierRoutes };
