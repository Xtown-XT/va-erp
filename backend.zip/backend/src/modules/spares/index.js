import sparesRoutes from "./spares.routes.js";

export { sparesRoutes };
