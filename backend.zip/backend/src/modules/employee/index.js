import employeeListRoutes from "./employeeList.routes.js";
import employeeAttendanceRoutes from "./employeeAttendance.routes.js";

export { employeeListRoutes, employeeAttendanceRoutes };
