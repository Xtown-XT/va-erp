import machineRoutes from "./machine.routes.js";

export { machineRoutes };
