import userRoutes from "./user.routes.js";

export { userRoutes };
