import compressorRoutes from "./compressor.routes.js";

export { compressorRoutes };
