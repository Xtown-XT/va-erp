import addressRoutes from "./address.routes.js";

export { addressRoutes };
