import brandRoutes from "./brand.routes.js";

export { brandRoutes };
