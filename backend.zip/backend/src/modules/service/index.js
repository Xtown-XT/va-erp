import serviceRoutes from "./service.routes.js";

export { serviceRoutes };
